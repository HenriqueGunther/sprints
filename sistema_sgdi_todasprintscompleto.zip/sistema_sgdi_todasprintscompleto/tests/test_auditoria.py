import json
import os
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as sgdi  # noqa: E402


class AuditoriaTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix='.db')
        os.close(fd)
        sgdi.app.config['DATABASE'] = self.db_path
        sgdi.app.config['TESTING'] = True
        self.client = sgdi.app.test_client()
        self.client.post('/identificar', data={'nome': 'Henrique'})
        self.client.post('/solicitantes', data={'nome': 'Ana', 'email': 'ana@x.com', 'departamento': 'TI'})

    def tearDown(self):
        os.remove(self.db_path)

    def logs(self, acao=None):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        sql = 'SELECT * FROM logs_auditoria' + (' WHERE acao=?' if acao else '') + ' ORDER BY id'
        rows = conn.execute(sql, (acao,) if acao else ()).fetchall()
        conn.close()
        return rows

    def criar(self, **extra):
        dados = {'titulo': 'Titulo', 'descricao': 'desc', 'solicitante_id': 1,
                 'prioridade': 'ALTA', 'responsavel': 'Bob'}
        dados.update(extra)
        return self.client.post('/nova_demanda', data=dados)

    def test_exige_identificacao(self):
        anon = sgdi.app.test_client()
        r = anon.get('/')
        self.assertEqual(r.status_code, 302)
        self.assertIn('/identificar', r.headers['Location'])
        r = anon.post('/nova_demanda', data={})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(len(self.logs('DEMANDA_CRIADA')), 0)

    def test_next_externo_e_ignorado(self):
        r = sgdi.app.test_client().post('/identificar', data={'nome': 'Zé', 'next': '//evil.com'})
        self.assertEqual(r.headers['Location'], '/')

    def test_criacao_gera_log(self):
        self.criar()
        log = self.logs('DEMANDA_CRIADA')[0]
        self.assertEqual(log['usuario'], 'Henrique')
        self.assertEqual(log['demanda_id'], 1)
        self.assertEqual(json.loads(log['detalhes'])['responsavel'], 'Bob')

    def test_edicao_registra_antes_e_depois(self):
        self.criar()
        self.client.post('/editar/1', data={'titulo': 'Titulo', 'descricao': 'desc', 'solicitante_id': 1,
                                            'prioridade': 'ALTA', 'responsavel': 'Carla', 'status': 'CONCLUÍDA'})
        log = self.logs('DEMANDA_EDITADA')[0]
        d = json.loads(log['detalhes'])
        self.assertEqual(d['responsavel'], {'de': 'Bob', 'para': 'Carla'})
        self.assertEqual(d['status'], {'de': 'ABERTA', 'para': 'CONCLUÍDA'})
        self.assertNotIn('titulo', d)

    def test_edicao_sem_mudanca_nao_gera_log(self):
        self.criar()
        self.client.post('/editar/1', data={'titulo': 'Titulo', 'descricao': 'desc', 'solicitante_id': 1,
                                            'prioridade': 'ALTA', 'responsavel': 'Bob', 'status': 'ABERTA'})
        self.assertEqual(len(self.logs('DEMANDA_EDITADA')), 0)

    def test_exclusao_exige_post_e_guarda_snapshot(self):
        self.criar()
        self.assertEqual(self.client.get('/deletar/1').status_code, 405)
        self.client.post('/adicionar_comentario/1', data={'autor': 'X', 'comentario': 'oi'})
        self.client.post('/deletar/1')
        log = self.logs('DEMANDA_EXCLUIDA')[0]
        d = json.loads(log['detalhes'])
        self.assertEqual(d['titulo'], 'Titulo')
        self.assertEqual(d['comentarios_removidos'], 1)
        conn = sqlite3.connect(self.db_path)
        self.assertEqual(conn.execute('SELECT COUNT(*) FROM demandas').fetchone()[0], 0)
        self.assertEqual(conn.execute('SELECT COUNT(*) FROM comentarios').fetchone()[0], 0)

    def test_comentario_e_solicitante(self):
        self.criar()
        self.client.post('/adicionar_comentario/1', data={'autor': 'X', 'comentario': 'oi'})
        self.assertEqual(len(self.logs('COMENTARIO_ADICIONADO')), 1)
        self.assertEqual(len(self.logs('SOLICITANTE_CADASTRADO')), 1)
        # duplicado não gera log
        self.client.post('/solicitantes', data={'nome': 'Ana', 'email': 'ana@x.com', 'departamento': 'TI'})
        self.assertEqual(len(self.logs('SOLICITANTE_CADASTRADO')), 1)

    def test_logs_sao_imutaveis(self):
        conn = sqlite3.connect(self.db_path)
        with self.assertRaises(sqlite3.DatabaseError):
            conn.execute('DELETE FROM logs_auditoria')
        with self.assertRaises(sqlite3.DatabaseError):
            conn.execute("UPDATE logs_auditoria SET usuario='x'")

    def test_validacoes_nao_criam_demanda_nem_log(self):
        self.criar(prioridade='XPTO')
        self.criar(titulo='   ')
        self.criar(responsavel='  ')
        self.criar(prazo='31/12/2026')
        self.criar(solicitante_id=999)
        self.assertEqual(len(self.logs('DEMANDA_CRIADA')), 0)

    def test_404_em_ids_inexistentes(self):
        self.assertEqual(self.client.get('/detalhes/99').status_code, 404)
        self.assertEqual(self.client.get('/editar/99').status_code, 404)
        self.assertEqual(self.client.post('/deletar/99').status_code, 404)
        self.assertEqual(self.client.post('/adicionar_comentario/99', data={'autor': 'a', 'comentario': 'b'}).status_code, 404)

    def test_paginas_de_auditoria(self):
        self.criar(titulo='<b>xss</b>')
        r = self.client.get('/auditoria')
        self.assertEqual(r.status_code, 200)
        self.assertIn('Demanda criada', r.get_data(as_text=True))
        self.assertNotIn('<b>xss</b>', r.get_data(as_text=True))  # autoescape
        for qs in ('?usuario=henrique', '?acao=DEMANDA_CRIADA', '?demanda_id=1', '?q=Bob',
                   '?data_inicial=2000-01-01&data_final=2100-01-01', '?data_inicial=abc', '?page=99'):
            self.assertEqual(self.client.get('/auditoria' + qs).status_code, 200, qs)
        self.assertIn('Histórico de alterações', self.client.get('/detalhes/1').get_data(as_text=True))

    def test_filtro_e_exportacao_csv(self):
        self.criar()
        r = self.client.get('/auditoria/exportar?acao=DEMANDA_CRIADA')
        self.assertEqual(r.status_code, 200)
        self.assertIn('text/csv', r.content_type)
        texto = r.get_data(as_text=True)
        self.assertIn('Demanda criada', texto)
        self.assertNotIn('Solicitante cadastrado', texto)
        self.assertEqual(len(self.logs('AUDITORIA_EXPORTADA')), 1)

    def test_demais_paginas_funcionam(self):
        self.criar()
        for url in ('/', '/dashboard', '/nova_demanda', '/solicitantes', '/editar/1', '/detalhes/1', '/buscar?q=a'):
            self.assertIn(self.client.get(url).status_code, (200, 302), url)


if __name__ == '__main__':
    unittest.main()
