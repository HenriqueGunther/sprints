"""
API REST do SGDI — Sprint 7.

Disponibiliza os dados de demandas e solicitantes para sistemas externos,
protegida por chave de API (header X-API-Key).
"""
import os
from datetime import date

from flask import Blueprint, jsonify, request

api = Blueprint('api', __name__, url_prefix='/api')

# Defina a chave real na variável de ambiente SGDI_API_KEY antes de rodar o sistema.
API_KEY = os.environ.get('SGDI_API_KEY', 'troque-essa-chave-em-producao')


# ---------------------------------------------------------------------------
# Autenticação por chave de API
# ---------------------------------------------------------------------------
@api.before_request
def exigir_api_key():
    chave_enviada = request.headers.get('X-API-Key')
    if chave_enviada != API_KEY:
        return jsonify({'erro': 'API key ausente ou inválida. '
                                 'Envie o header X-API-Key.'}), 401


# ---------------------------------------------------------------------------
# Serialização
# ---------------------------------------------------------------------------
def serializar_demanda(row):
    return {
        'id': row['id'],
        'titulo': row['titulo'],
        'descricao': row['descricao'],
        'prioridade': row['prioridade'],
        'responsavel': row['responsavel'],
        'status': row['status'],
        'prazo': row['prazo'],
        'data_criacao': row['data_criacao'],
        'data_conclusao': row['data_conclusao'],
        'solicitante_id': row['solicitante_id'],
        'solicitante_nome': row['solicitante_nome'] if 'solicitante_nome' in row.keys() else None,
    }


def serializar_solicitante(row):
    return {
        'id': row['id'],
        'nome': row['nome'],
        'email': row['email'],
        'departamento': row['departamento'],
    }


# ---------------------------------------------------------------------------
# /api/demandas
# ---------------------------------------------------------------------------
@api.route('/demandas', methods=['GET'])
def listar_demandas():
    from app import get_db, ensure_schema  # import local para evitar ciclo de import

    conn = get_db()
    ensure_schema(conn)

    status = request.args.get('status', '').strip().upper()
    where, params = [], []
    if status:
        where.append('d.status = ?')
        params.append(status)
    clause = 'WHERE ' + ' AND '.join(where) if where else ''

    linhas = conn.execute(f'''SELECT d.*, s.nome AS solicitante_nome
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        {clause}
        ORDER BY d.id DESC''', params).fetchall()
    conn.close()
    return jsonify([serializar_demanda(r) for r in linhas])


@api.route('/demandas/<int:demanda_id>', methods=['GET'])
def obter_demanda(demanda_id):
    from app import get_db, ensure_schema

    conn = get_db()
    ensure_schema(conn)
    linha = conn.execute('''SELECT d.*, s.nome AS solicitante_nome
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.id = ?''', (demanda_id,)).fetchone()
    conn.close()
    if linha is None:
        return jsonify({'erro': 'Demanda não encontrada'}), 404
    return jsonify(serializar_demanda(linha))


@api.route('/demandas', methods=['POST'])
def criar_demanda():
    from app import get_db, ensure_schema, agora, registrar_log, snapshot_demanda, PRIORIDADES_VALIDAS

    dados = request.get_json(silent=True)
    if not dados:
        return jsonify({'erro': 'Envie um corpo JSON.'}), 400

    titulo = (dados.get('titulo') or '').strip()
    responsavel = (dados.get('responsavel') or '').strip()
    prioridade = dados.get('prioridade', 'MÉDIA')
    descricao = (dados.get('descricao') or '').strip()
    prazo = dados.get('prazo')
    solicitante_id = dados.get('solicitante_id')

    if not titulo:
        return jsonify({'erro': "Campo 'titulo' é obrigatório."}), 400
    if not responsavel:
        return jsonify({'erro': "Campo 'responsavel' é obrigatório."}), 400
    if prioridade not in PRIORIDADES_VALIDAS:
        return jsonify({'erro': f"Campo 'prioridade' deve ser um de {PRIORIDADES_VALIDAS}."}), 400
    if not solicitante_id:
        return jsonify({'erro': "Campo 'solicitante_id' é obrigatório."}), 400

    conn = get_db()
    ensure_schema(conn)
    existe = conn.execute('SELECT 1 FROM solicitantes WHERE id=?', (solicitante_id,)).fetchone()
    if not existe:
        conn.close()
        return jsonify({'erro': 'solicitante_id não existe.'}), 400

    cursor = conn.execute('''INSERT INTO demandas
        (titulo, descricao, solicitante, solicitante_id, data_criacao, prioridade, responsavel, status, prazo)
        VALUES (?, ?, '', ?, ?, ?, ?, 'ABERTA', ?)''',
        (titulo, descricao, solicitante_id, agora(), prioridade, responsavel, prazo))
    demanda_id = cursor.lastrowid
    registrar_log(conn, 'DEMANDA_CRIADA', 'demanda', demanda_id,
                  f'Demanda #{demanda_id} "{titulo}" criada via API',
                  detalhes=snapshot_demanda(conn, demanda_id), demanda_id=demanda_id,
                  usuario='API')
    conn.commit()
    linha = conn.execute('''SELECT d.*, s.nome AS solicitante_nome
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.id = ?''', (demanda_id,)).fetchone()
    conn.close()
    return jsonify(serializar_demanda(linha)), 201


@api.route('/demandas/<int:demanda_id>', methods=['PUT', 'PATCH'])
def atualizar_demanda(demanda_id):
    from app import (get_db, ensure_schema, agora, registrar_log, snapshot_demanda,
                      diferencas, CAMPOS_DEMANDA, STATUS_VALIDOS)

    dados = request.get_json(silent=True)
    if not dados:
        return jsonify({'erro': 'Envie um corpo JSON.'}), 400

    conn = get_db()
    ensure_schema(conn)
    atual = conn.execute('SELECT * FROM demandas WHERE id=?', (demanda_id,)).fetchone()
    if atual is None:
        conn.close()
        return jsonify({'erro': 'Demanda não encontrada'}), 404

    antes = snapshot_demanda(conn, demanda_id)
    titulo = dados.get('titulo', atual['titulo'])
    descricao = dados.get('descricao', atual['descricao'])
    responsavel = dados.get('responsavel', atual['responsavel'])
    prioridade = dados.get('prioridade', atual['prioridade'])
    prazo = dados.get('prazo', atual['prazo'])
    solicitante_id = dados.get('solicitante_id', atual['solicitante_id'])
    status = dados.get('status', atual['status'])
    if status not in STATUS_VALIDOS:
        conn.close()
        return jsonify({'erro': f'status deve ser um de {STATUS_VALIDOS}.'}), 400

    if status == 'CONCLUÍDA':
        data_conclusao = atual['data_conclusao'] if atual['status'] == 'CONCLUÍDA' and atual['data_conclusao'] else agora()
    else:
        data_conclusao = None

    conn.execute('''UPDATE demandas SET titulo=?, descricao=?, solicitante_id=?,
        prioridade=?, responsavel=?, status=?, prazo=?, data_conclusao=? WHERE id=?''',
        (titulo, descricao, solicitante_id, prioridade, responsavel, status, prazo, data_conclusao, demanda_id))

    depois = snapshot_demanda(conn, demanda_id)
    mudancas = diferencas(antes, depois)
    if mudancas:
        campos = ', '.join(CAMPOS_DEMANDA[c] for c in mudancas)
        registrar_log(conn, 'DEMANDA_EDITADA', 'demanda', demanda_id,
                      f'Demanda #{demanda_id} editada via API (alterado: {campos})',
                      detalhes=mudancas, demanda_id=demanda_id, usuario='API')
    conn.commit()
    linha = conn.execute('''SELECT d.*, s.nome AS solicitante_nome
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.id = ?''', (demanda_id,)).fetchone()
    conn.close()
    return jsonify(serializar_demanda(linha))


@api.route('/demandas/<int:demanda_id>', methods=['DELETE'])
def excluir_demanda(demanda_id):
    from app import get_db, ensure_schema, registrar_log, snapshot_demanda

    conn = get_db()
    ensure_schema(conn)
    antes = snapshot_demanda(conn, demanda_id)
    if antes is None:
        conn.close()
        return jsonify({'erro': 'Demanda não encontrada'}), 404

    total_comentarios = conn.execute(
        'SELECT COUNT(*) FROM comentarios WHERE demanda_id=?', (demanda_id,)).fetchone()[0]
    conn.execute('DELETE FROM comentarios WHERE demanda_id=?', (demanda_id,))
    conn.execute('DELETE FROM demandas WHERE id=?', (demanda_id,))
    antes['comentarios_removidos'] = total_comentarios
    registrar_log(conn, 'DEMANDA_EXCLUIDA', 'demanda', demanda_id,
                  f'Demanda #{demanda_id} "{antes["titulo"]}" excluída via API',
                  detalhes=antes, demanda_id=demanda_id, usuario='API')
    conn.commit()
    conn.close()
    return jsonify({'mensagem': f'Demanda #{demanda_id} excluída.'})


# ---------------------------------------------------------------------------
# /api/solicitantes
# ---------------------------------------------------------------------------
@api.route('/solicitantes', methods=['GET'])
def listar_solicitantes():
    from app import get_db, ensure_schema

    conn = get_db()
    ensure_schema(conn)
    linhas = conn.execute('SELECT id, nome, email, departamento FROM solicitantes ORDER BY nome').fetchall()
    conn.close()
    return jsonify([serializar_solicitante(r) for r in linhas])
