import sqlite3
import sys
from datetime import date, timedelta

from app import get_db, ensure_schema

# Cria/atualiza todas as tabelas (inclui logs_auditoria) usando a mesma rotina do app.
conn = get_db()
ensure_schema(conn)
cursor = conn.cursor()

reset = '--reset' in sys.argv
ja_tem_dados = cursor.execute('SELECT COUNT(*) FROM demandas').fetchone()[0] > 0
if ja_tem_dados and not reset:
    print("Banco já possui dados: estrutura atualizada, dados preservados.")
    print("Use 'python init_db.py --reset' para apagar demandas/comentários e recarregar o exemplo.")
    conn.close()
    sys.exit(0)

# Os logs de auditoria NUNCA são apagados (são imutáveis).
cursor.execute("DELETE FROM demandas")
cursor.execute("DELETE FROM comentarios")

hoje = date.today()
def dia(delta):
    return (hoje + timedelta(days=delta)).isoformat()

# (id, titulo, descricao, solicitante, data_criacao, prioridade, responsavel, status, prazo, data_conclusao)
demandas = [
    (1, 'Corrigir bug no login', 'Usuários não conseguem fazer login', 'João Silva', '2024-01-15 10:30:00', 'ALTA', 'Tech Team', 'CONCLUÍDA', '2024-01-20', '2024-01-17 16:00:00'),
    (2, 'Implementar relatório de vendas', 'Precisamos de um relatório mensal', 'Maria Santos', '2024-01-16 14:20:00', 'MÉDIA', 'Desenvolvedor', 'ABERTA', dia(10), None),
    (3, 'Melhorar performance', 'Sistema está lento', 'Pedro Costa', '2024-01-17 09:15:00', 'ALTA', 'Tech Team', 'ABERTA', dia(-5), None),
    (4, 'Adicionar filtros', 'Usuários querem filtrar demandas', 'Ana Lima', '2024-01-18 11:00:00', 'BAIXA', 'Desenvolvedor', 'CONCLUÍDA', '2024-02-01', '2024-01-25 10:00:00'),
    (5, 'Integrar pagamento', 'Gateway de pagamento no checkout', 'João Silva', '2024-02-01 09:00:00', 'ALTA', 'Desenvolvedor', 'ABERTA', dia(7), None),
    (6, 'Migrar servidor', 'Mudança para nova infraestrutura', 'Pedro Costa', '2024-02-05 15:00:00', 'MÉDIA', 'Tech Team', 'CANCELADA', None, None),
    (7, 'Revisar permissões', 'Auditoria de acessos', 'Ana Lima', '2024-02-10 08:30:00', 'MÉDIA', 'Tech Team', 'ABERTA', dia(-2), None),
    (8, 'Tela de perfil', 'Novo layout do perfil', 'Maria Santos', '2024-02-12 13:00:00', 'BAIXA', 'Desenvolvedor', 'CONCLUÍDA', '2024-03-01', '2024-02-20 17:30:00'),
]
cursor.executemany('''INSERT INTO demandas
    (id, titulo, descricao, solicitante, data_criacao, prioridade, responsavel, status, prazo, data_conclusao)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', demandas)

comentarios = [
    (1, 1, 'Vou investigar esse bug', 'Tech Team', '2024-01-15 11:00:00'),
    (2, 1, 'Bug corrigido na branch develop', 'Desenvolvedor', '2024-01-15 16:30:00')
]
cursor.executemany('''INSERT INTO comentarios
    (id, demanda_id, comentario, autor, data) VALUES (?, ?, ?, ?, ?)''', comentarios)

conn.commit()
conn.close()
print("Banco de dados criado com sucesso!")
