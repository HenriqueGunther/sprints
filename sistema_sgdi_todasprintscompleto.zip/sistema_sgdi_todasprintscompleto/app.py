import csv
import io
import json
import os
import sqlite3
from datetime import datetime, date
from pathlib import Path

from flask import (Flask, render_template, request, redirect, flash, url_for,
                   session, abort, Response)

app = Flask(__name__)
# Em produção defina a variável de ambiente SECRET_KEY.
app.secret_key = os.environ.get('SECRET_KEY', 'sgdi-chave-de-desenvolvimento')
app.config['DATABASE'] = str(Path(app.root_path) / 'demandas.db')

from api import api
app.register_blueprint(api)

PAGE_SIZE = 10
AUDIT_PAGE_SIZE = 20
STATUS_VALIDOS = ('ABERTA', 'CONCLUÍDA', 'CANCELADA')
PRIORIDADES_VALIDAS = ('ALTA', 'MÉDIA', 'BAIXA')

# Ações registradas na auditoria (código -> rótulo exibido na tela)
ACOES_AUDITORIA = {
    'DEMANDA_CRIADA': 'Demanda criada',
    'DEMANDA_EDITADA': 'Demanda editada',
    'DEMANDA_EXCLUIDA': 'Demanda excluída',
    'COMENTARIO_ADICIONADO': 'Comentário adicionado',
    'SOLICITANTE_CADASTRADO': 'Solicitante cadastrado',
    'USUARIO_IDENTIFICADO': 'Usuário identificado (entrada)',
    'USUARIO_SAIU': 'Usuário saiu',
    'AUDITORIA_EXPORTADA': 'Auditoria exportada (CSV)',
}

# Campos de demanda monitorados na edição (campo -> rótulo)
CAMPOS_DEMANDA = {
    'titulo': 'Título',
    'descricao': 'Descrição',
    'solicitante': 'Solicitante',
    'prioridade': 'Prioridade',
    'responsavel': 'Responsável',
    'status': 'Status',
    'prazo': 'Prazo',
}


# ---------------------------------------------------------------------------
# Banco de dados
# ---------------------------------------------------------------------------
def get_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def ensure_schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS demandas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT NOT NULL,
        descricao TEXT,
        solicitante TEXT NOT NULL DEFAULT '',
        data_criacao TEXT NOT NULL,
        prioridade TEXT NOT NULL DEFAULT 'MÉDIA',
        responsavel TEXT NOT NULL DEFAULT ''
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS comentarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        demanda_id INTEGER,
        comentario TEXT,
        autor TEXT,
        data TEXT
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS solicitantes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL COLLATE NOCASE UNIQUE,
        email TEXT NOT NULL COLLATE NOCASE UNIQUE,
        departamento TEXT NOT NULL
    )''')
    columns = [row['name'] for row in conn.execute('PRAGMA table_info(demandas)')]
    if 'solicitante_id' not in columns:
        conn.execute('ALTER TABLE demandas ADD COLUMN solicitante_id INTEGER REFERENCES solicitantes(id)')
    if 'status' not in columns:
        conn.execute("ALTER TABLE demandas ADD COLUMN status TEXT NOT NULL DEFAULT 'ABERTA'")
    if 'prazo' not in columns:
        conn.execute('ALTER TABLE demandas ADD COLUMN prazo TEXT')
    if 'data_conclusao' not in columns:
        conn.execute('ALTER TABLE demandas ADD COLUMN data_conclusao TEXT')
    ensure_audit_schema(conn)
    conn.commit()


def ensure_audit_schema(conn):
    """Cria a tabela de logs de auditoria e os gatilhos que a tornam imutável."""
    conn.execute('''CREATE TABLE IF NOT EXISTS logs_auditoria (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data_hora TEXT NOT NULL,
        usuario TEXT NOT NULL,
        ip TEXT,
        acao TEXT NOT NULL,
        entidade TEXT NOT NULL,
        entidade_id INTEGER,
        demanda_id INTEGER,
        descricao TEXT NOT NULL,
        detalhes TEXT
    )''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_logs_data ON logs_auditoria(data_hora)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_logs_usuario ON logs_auditoria(usuario)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_logs_demanda ON logs_auditoria(demanda_id)')
    conn.execute('''CREATE TRIGGER IF NOT EXISTS logs_auditoria_sem_update
        BEFORE UPDATE ON logs_auditoria
        BEGIN SELECT RAISE(ABORT, 'Logs de auditoria não podem ser alterados'); END''')
    conn.execute('''CREATE TRIGGER IF NOT EXISTS logs_auditoria_sem_delete
        BEFORE DELETE ON logs_auditoria
        BEGIN SELECT RAISE(ABORT, 'Logs de auditoria não podem ser excluídos'); END''')


# ---------------------------------------------------------------------------
# Auditoria
# ---------------------------------------------------------------------------
def agora():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def usuario_atual():
    return session.get('usuario')


def registrar_log(conn, acao, entidade, entidade_id, descricao, detalhes=None, demanda_id=None, usuario=None):
    """Grava um log de auditoria. NÃO faz commit: o log entra na mesma transação
    da operação auditada (ou as duas coisas acontecem, ou nenhuma)."""
    conn.execute(
        '''INSERT INTO logs_auditoria
           (data_hora, usuario, ip, acao, entidade, entidade_id, demanda_id, descricao, detalhes)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (agora(), usuario or usuario_atual() or 'Não identificado', request.remote_addr,
         acao, entidade, entidade_id, demanda_id, descricao,
         json.dumps(detalhes, ensure_ascii=False) if detalhes is not None else None))


def snapshot_demanda(conn, demanda_id):
    """Retorna os dados 'legíveis' de uma demanda (solicitante já resolvido pelo nome)."""
    row = conn.execute('''SELECT d.*, s.nome AS solicitante_nome
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.id = ?''', (demanda_id,)).fetchone()
    if row is None:
        return None
    return {
        'titulo': row['titulo'],
        'descricao': row['descricao'] or '',
        'solicitante': row['solicitante_nome'] or row['solicitante'] or '(legado)',
        'prioridade': row['prioridade'],
        'responsavel': row['responsavel'],
        'status': row['status'],
        'prazo': row['prazo'] or '',
    }


def diferencas(antes, depois):
    return {campo: {'de': antes[campo], 'para': depois[campo]}
            for campo in CAMPOS_DEMANDA if antes[campo] != depois[campo]}


@app.template_filter('fromjson')
def fromjson(valor):
    try:
        return json.loads(valor) if valor else None
    except (TypeError, ValueError):
        return None


@app.context_processor
def contexto_global():
    return {'usuario_logado': usuario_atual(), 'CAMPOS_DEMANDA': CAMPOS_DEMANDA,
            'ACOES_AUDITORIA': ACOES_AUDITORIA}


@app.before_request
def exigir_identificacao():
    """Sem login/senha no sistema, o usuário precisa ao menos se identificar
    para que cada ação fique associada a uma pessoa nos logs."""
    if request.endpoint in (None, 'static', 'identificar') or request.blueprint == 'api':
        return None
    if not usuario_atual():
        destino = request.full_path.rstrip('?') if request.method == 'GET' else '/'
        return redirect(url_for('identificar', next=destino))
    return None


def caminho_seguro(destino):
    if destino and destino.startswith('/') and not destino.startswith('//') and '\\' not in destino:
        return destino
    return '/'


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def get_solicitantes(conn):
    return conn.execute(
        'SELECT id, nome, email, departamento FROM solicitantes ORDER BY nome'
    ).fetchall()


def solicitante_label(demanda):
    return demanda['solicitante_nome'] or demanda['solicitante'] or 'Solicitante legado'


def data_valida(valor):
    try:
        date.fromisoformat(valor)
        return True
    except ValueError:
        return False


def validar_demanda(conn, form):
    """Valida e normaliza os dados do formulário de demanda.
    Retorna (dados, erro). Em caso de erro, dados é None."""
    titulo = form.get('titulo', '').strip()
    descricao = form.get('descricao', '').strip()
    responsavel = form.get('responsavel', '').strip()
    prioridade = form.get('prioridade', '')
    prazo = form.get('prazo', '').strip() or None
    solicitante_id = form.get('solicitante_id', type=int)
    if not titulo:
        return None, 'Informe o título da demanda.'
    if not responsavel:
        return None, 'Informe o responsável pela demanda.'
    if prioridade not in PRIORIDADES_VALIDAS:
        return None, 'Selecione uma prioridade válida.'
    if prazo and not data_valida(prazo):
        return None, 'Informe um prazo válido.'
    if not solicitante_id:
        return None, 'Selecione um solicitante cadastrado.'
    existe = conn.execute('SELECT 1 FROM solicitantes WHERE id=?', (solicitante_id,)).fetchone()
    if not existe:
        return None, 'O solicitante selecionado não existe.'
    return {'titulo': titulo, 'descricao': descricao, 'responsavel': responsavel,
            'prioridade': prioridade, 'prazo': prazo, 'solicitante_id': solicitante_id}, None


# ---------------------------------------------------------------------------
# Identificação do usuário
# ---------------------------------------------------------------------------
@app.route('/identificar', methods=['GET', 'POST'])
def identificar():
    destino = caminho_seguro(request.values.get('next'))
    if request.method == 'POST':
        nome = request.form.get('nome', '').strip()
        if len(nome) < 2:
            flash('Informe seu nome (mínimo 2 caracteres).')
            return redirect(url_for('identificar', next=destino))
        nome = nome[:80]
        conn = get_db()
        ensure_schema(conn)
        session.clear()
        session['usuario'] = nome
        registrar_log(conn, 'USUARIO_IDENTIFICADO', 'usuario', None,
                      f'Usuário "{nome}" identificou-se no sistema', usuario=nome)
        conn.commit()
        conn.close()
        return redirect(destino)
    return render_template('identificar.html', destino=destino)


@app.route('/sair', methods=['POST'])
def sair():
    conn = get_db()
    ensure_schema(conn)
    registrar_log(conn, 'USUARIO_SAIU', 'usuario', None,
                  f'Usuário "{usuario_atual()}" saiu do sistema')
    conn.commit()
    conn.close()
    session.clear()
    return redirect(url_for('identificar'))


# ---------------------------------------------------------------------------
# Demandas
# ---------------------------------------------------------------------------
@app.route('/')
def index():
    conn = get_db()
    ensure_schema(conn)
    solicitantes = get_solicitantes(conn)
    solicitante_id = request.args.get('solicitante_id', type=int)
    prioridade = request.args.get('prioridade', '')
    departamento = request.args.get('departamento', '').strip()
    termo = request.args.get('q', '').strip()
    data_inicial = request.args.get('data_inicial', '').strip()
    data_final = request.args.get('data_final', '').strip()
    pagina = max(request.args.get('page', 1, type=int), 1)

    datas_validas = True
    for valor in (data_inicial, data_final):
        if valor and not data_valida(valor):
            datas_validas = False
            break
    if not datas_validas:
        flash('Informe datas válidas para filtrar o período.')
        data_inicial = ''
        data_final = ''
    if data_inicial and data_final and data_inicial > data_final:
        flash('A data inicial não pode ser posterior à data final.')
        data_inicial = ''
        data_final = ''

    where = []
    params = []
    if solicitante_id:
        where.append('d.solicitante_id = ?')
        params.append(solicitante_id)
    if prioridade in PRIORIDADES_VALIDAS:
        where.append('d.prioridade = ?')
        params.append(prioridade)
    if departamento:
        where.append('s.departamento = ?')
        params.append(departamento)
    if data_inicial:
        where.append('date(d.data_criacao) >= date(?)')
        params.append(data_inicial)
    if data_final:
        where.append('date(d.data_criacao) <= date(?)')
        params.append(data_final)
    if termo:
        where.append('(d.titulo LIKE ? OR d.descricao LIKE ?)')
        params.extend((f'%{termo}%', f'%{termo}%'))
    clause = 'WHERE ' + ' AND '.join(where) if where else ''
    total_query = f'''SELECT COUNT(*)
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        {clause}'''
    total_demandas = conn.execute(total_query, params).fetchone()[0]
    total_paginas = max((total_demandas + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    pagina = min(pagina, total_paginas)
    offset = (pagina - 1) * PAGE_SIZE
    demandas = conn.execute(f'''SELECT d.*, s.nome AS solicitante_nome,
            s.email AS solicitante_email, s.departamento AS solicitante_departamento
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        {clause}
        ORDER BY CASE d.prioridade WHEN 'ALTA' THEN 1 WHEN 'MÉDIA' THEN 2 ELSE 3 END,
            d.id DESC LIMIT ? OFFSET ?''', params + [PAGE_SIZE, offset]).fetchall()
    resumo = conn.execute('''SELECT s.id, s.nome, s.email, s.departamento,
            COUNT(d.id) AS total_demandas
        FROM solicitantes s LEFT JOIN demandas d ON d.solicitante_id = s.id
        GROUP BY s.id ORDER BY s.nome''').fetchall()
    departamentos = conn.execute(
        'SELECT DISTINCT departamento FROM solicitantes ORDER BY departamento'
    ).fetchall()
    conn.close()
    query_params = {key: value for key, value in request.args.to_dict().items() if key != 'page'}
    inicio_exibicao = (pagina - 1) * PAGE_SIZE + 1 if total_demandas else 0
    fim_exibicao = min(pagina * PAGE_SIZE, total_demandas) if total_demandas else 0
    return render_template('index.html', demandas=demandas, solicitantes=solicitantes,
                           departamentos=departamentos, resumo=resumo,
                           filtro_solicitante=solicitante_id,
                           filtro_prioridade=prioridade,
                           filtro_departamento=departamento, termo=termo,
                           data_inicial=data_inicial, data_final=data_final,
                           total_demandas=total_demandas, pagina_atual=pagina,
                           total_paginas=total_paginas, PAGE_SIZE=PAGE_SIZE,
                           inicio_exibicao=inicio_exibicao, fim_exibicao=fim_exibicao,
                           query_params=query_params, solicitante_label=solicitante_label)


@app.route('/nova_demanda', methods=['GET', 'POST'])
def nova_demanda():
    conn = get_db()
    ensure_schema(conn)
    if request.method == 'POST':
        dados, erro = validar_demanda(conn, request.form)
        if erro:
            conn.close()
            flash(erro)
            return redirect('/nova_demanda')
        cursor = conn.execute('''INSERT INTO demandas
            (titulo, descricao, solicitante, solicitante_id, data_criacao, prioridade, responsavel, status, prazo)
            VALUES (?, ?, '', ?, ?, ?, ?, 'ABERTA', ?)''',
            (dados['titulo'], dados['descricao'], dados['solicitante_id'], agora(),
             dados['prioridade'], dados['responsavel'], dados['prazo']))
        demanda_id = cursor.lastrowid
        registrar_log(conn, 'DEMANDA_CRIADA', 'demanda', demanda_id,
                      f'Demanda #{demanda_id} "{dados["titulo"]}" criada',
                      detalhes=snapshot_demanda(conn, demanda_id), demanda_id=demanda_id)
        conn.commit()
        conn.close()
        flash('Demanda criada com sucesso!')
        return redirect('/')
    solicitantes = get_solicitantes(conn)
    conn.close()
    return render_template('nova_demanda.html', solicitantes=solicitantes)


@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    conn = get_db()
    ensure_schema(conn)
    atual = conn.execute('SELECT status, data_conclusao FROM demandas WHERE id=?', (id,)).fetchone()
    if atual is None:
        conn.close()
        abort(404)
    if request.method == 'POST':
        dados, erro = validar_demanda(conn, request.form)
        if erro:
            conn.close()
            flash(erro)
            return redirect(f'/editar/{id}')
        status = request.form.get('status', 'ABERTA')
        if status not in STATUS_VALIDOS:
            status = 'ABERTA'
        if status == 'CONCLUÍDA':
            # mantém a data original se já estava concluída
            data_conclusao = (atual['data_conclusao'] if atual['status'] == 'CONCLUÍDA' and atual['data_conclusao']
                              else agora())
        else:
            data_conclusao = None
        antes = snapshot_demanda(conn, id)
        conn.execute('''UPDATE demandas SET titulo=?, descricao=?, solicitante=?,
            solicitante_id=?, prioridade=?, responsavel=?, status=?, prazo=?, data_conclusao=? WHERE id=?''',
            (dados['titulo'], dados['descricao'], '', dados['solicitante_id'],
             dados['prioridade'], dados['responsavel'], status, dados['prazo'], data_conclusao, id))
        depois = snapshot_demanda(conn, id)
        mudancas = diferencas(antes, depois)
        if mudancas:
            campos = ', '.join(CAMPOS_DEMANDA[c] for c in mudancas)
            registrar_log(conn, 'DEMANDA_EDITADA', 'demanda', id,
                          f'Demanda #{id} editada (alterado: {campos})',
                          detalhes=mudancas, demanda_id=id)
            flash('Demanda atualizada com sucesso!')
        else:
            flash('Nenhuma alteração foi feita.')
        conn.commit()
        conn.close()
        return redirect('/')
    demanda = conn.execute('''SELECT d.*, s.nome AS solicitante_nome
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.id=?''', (id,)).fetchone()
    solicitantes = get_solicitantes(conn)
    conn.close()
    return render_template('editar.html', demanda=demanda, solicitantes=solicitantes,
                           solicitante_label=solicitante_label)


@app.route('/deletar/<int:id>', methods=['POST'])
def deletar(id):
    conn = get_db()
    ensure_schema(conn)
    antes = snapshot_demanda(conn, id)
    if antes is None:
        conn.close()
        abort(404)
    total_comentarios = conn.execute(
        'SELECT COUNT(*) FROM comentarios WHERE demanda_id=?', (id,)).fetchone()[0]
    conn.execute('DELETE FROM comentarios WHERE demanda_id=?', (id,))
    conn.execute('DELETE FROM demandas WHERE id=?', (id,))
    antes['comentarios_removidos'] = total_comentarios
    registrar_log(conn, 'DEMANDA_EXCLUIDA', 'demanda', id,
                  f'Demanda #{id} "{antes["titulo"]}" excluída', detalhes=antes, demanda_id=id)
    conn.commit()
    conn.close()
    flash('Demanda deletada!')
    return redirect('/')


@app.route('/buscar')
def buscar():
    return redirect(url_for('index', q=request.args.get('q', '')))


@app.route('/detalhes/<int:id>')
def detalhes(id):
    conn = get_db()
    ensure_schema(conn)
    demanda = conn.execute('''SELECT d.*, s.nome AS solicitante_nome,
        s.email AS solicitante_email, s.departamento AS solicitante_departamento
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.id=?''', (id,)).fetchone()
    if demanda is None:
        conn.close()
        abort(404)
    comentarios = conn.execute(
        'SELECT * FROM comentarios WHERE demanda_id=? ORDER BY id DESC', (id,)).fetchall()
    historico = conn.execute(
        'SELECT * FROM logs_auditoria WHERE demanda_id=? ORDER BY id DESC', (id,)).fetchall()
    conn.close()
    return render_template('detalhes.html', demanda=demanda, comentarios=comentarios,
                           historico=historico, solicitante_label=solicitante_label)


@app.route('/solicitantes', methods=['GET', 'POST'])
def solicitantes():
    conn = get_db()
    ensure_schema(conn)
    if request.method == 'POST':
        nome = request.form.get('nome', '').strip()
        email = request.form.get('email', '').strip()
        departamento = request.form.get('departamento', '').strip()
        if not (nome and email and departamento):
            flash('Preencha nome, e-mail e departamento.')
            conn.close()
            return redirect('/solicitantes')
        try:
            cursor = conn.execute(
                'INSERT INTO solicitantes (nome, email, departamento) VALUES (?, ?, ?)',
                (nome, email, departamento))
            registrar_log(conn, 'SOLICITANTE_CADASTRADO', 'solicitante', cursor.lastrowid,
                          f'Solicitante "{nome}" cadastrado',
                          detalhes={'nome': nome, 'email': email, 'departamento': departamento})
            conn.commit()
            flash('Solicitante cadastrado com sucesso!')
        except sqlite3.IntegrityError:
            conn.rollback()
            flash('Já existe um solicitante com esse nome ou e-mail.')
        conn.close()
        return redirect('/solicitantes')
    cadastrados = get_solicitantes(conn)
    conn.close()
    return render_template('solicitantes.html', solicitantes=cadastrados)


@app.route('/adicionar_comentario/<int:demanda_id>', methods=['POST'])
def adicionar_comentario(demanda_id):
    conn = get_db()
    ensure_schema(conn)
    if not conn.execute('SELECT 1 FROM demandas WHERE id=?', (demanda_id,)).fetchone():
        conn.close()
        abort(404)
    autor = request.form.get('autor', '').strip()
    texto = request.form.get('comentario', '').strip()
    if not autor or not texto:
        conn.close()
        flash('Informe seu nome e o comentário.')
        return redirect(f'/detalhes/{demanda_id}')
    cursor = conn.execute('''INSERT INTO comentarios (demanda_id, comentario, autor, data)
        VALUES (?, ?, ?, ?)''', (demanda_id, texto, autor, agora()))
    registrar_log(conn, 'COMENTARIO_ADICIONADO', 'comentario', cursor.lastrowid,
                  f'Comentário adicionado na demanda #{demanda_id}',
                  detalhes={'autor_informado': autor, 'comentario': texto}, demanda_id=demanda_id)
    conn.commit()
    conn.close()
    return redirect(f'/detalhes/{demanda_id}')


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route('/dashboard')
def dashboard():
    conn = get_db()
    ensure_schema(conn)
    hoje = date.today().isoformat()
    total = conn.execute('SELECT COUNT(*) FROM demandas').fetchone()[0]

    def contar(where, params=()):
        return conn.execute(f'SELECT COUNT(*) FROM demandas WHERE {where}', params).fetchone()[0]

    atrasadas = contar("status='ABERTA' AND prazo IS NOT NULL AND prazo != '' AND date(prazo) < date(?)", (hoje,))
    abertas_total = contar("status='ABERTA'")
    abertas = abertas_total - atrasadas          # abertas no prazo (ou sem prazo)
    concluidas = contar("status='CONCLUÍDA'")
    canceladas = contar("status='CANCELADA'")

    def pct(n):
        return round(n * 100 / total, 1) if total else 0

    kpis = [
        {'nome': 'Abertas', 'qtd': abertas, 'pct': pct(abertas), 'classe': 'aberta'},
        {'nome': 'Concluídas', 'qtd': concluidas, 'pct': pct(concluidas), 'classe': 'concluida'},
        {'nome': 'Atrasadas', 'qtd': atrasadas, 'pct': pct(atrasadas), 'classe': 'atrasada'},
    ]

    criticas = conn.execute('''SELECT d.id, d.titulo, d.responsavel, d.status, d.prazo,
            s.nome AS solicitante_nome, d.solicitante,
            (d.status='ABERTA' AND d.prazo IS NOT NULL AND d.prazo != '' AND date(d.prazo) < date(?)) AS atrasada
        FROM demandas d LEFT JOIN solicitantes s ON s.id = d.solicitante_id
        WHERE d.prioridade='ALTA'
        ORDER BY CASE d.status WHEN 'ABERTA' THEN 1 WHEN 'CONCLUÍDA' THEN 2 ELSE 3 END, d.id DESC''',
        (hoje,)).fetchall()
    criticas_abertas = sum(1 for c in criticas if c['status'] == 'ABERTA')

    por_responsavel = conn.execute('''SELECT responsavel, COUNT(*) AS qtd
        FROM demandas WHERE status='ABERTA'
        GROUP BY responsavel ORDER BY qtd DESC, responsavel''').fetchall()
    max_resp = max((r['qtd'] for r in por_responsavel), default=1)

    tempo = conn.execute('''SELECT AVG(julianday(data_conclusao) - julianday(data_criacao)), COUNT(*)
        FROM demandas WHERE status='CONCLUÍDA' AND data_conclusao IS NOT NULL''').fetchone()
    tempo_medio = round(tempo[0], 1) if tempo[0] is not None else None
    conn.close()
    return render_template('dashboard.html', total=total, kpis=kpis, canceladas=canceladas,
                           criticas=criticas, criticas_abertas=criticas_abertas,
                           por_responsavel=por_responsavel, max_resp=max_resp,
                           tempo_medio=tempo_medio, base_tempo=tempo[1], hoje=hoje)


# ---------------------------------------------------------------------------
# Consulta de auditoria
# ---------------------------------------------------------------------------
def filtros_auditoria():
    """Lê os filtros da query string e devolve (filtros, where_sql, params, avisos)."""
    filtros = {
        'usuario': request.args.get('usuario', '').strip(),
        'acao': request.args.get('acao', '').strip(),
        'demanda_id': request.args.get('demanda_id', type=int),
        'q': request.args.get('q', '').strip(),
        'data_inicial': request.args.get('data_inicial', '').strip(),
        'data_final': request.args.get('data_final', '').strip(),
    }
    avisos = []
    for chave in ('data_inicial', 'data_final'):
        if filtros[chave] and not data_valida(filtros[chave]):
            avisos.append('Informe datas válidas para filtrar o período.')
            filtros['data_inicial'] = filtros['data_final'] = ''
            break
    if filtros['data_inicial'] and filtros['data_final'] and filtros['data_inicial'] > filtros['data_final']:
        avisos.append('A data inicial não pode ser posterior à data final.')
        filtros['data_inicial'] = filtros['data_final'] = ''

    where, params = [], []
    if filtros['usuario']:
        where.append('usuario = ? COLLATE NOCASE')
        params.append(filtros['usuario'])
    if filtros['acao'] in ACOES_AUDITORIA:
        where.append('acao = ?')
        params.append(filtros['acao'])
    else:
        filtros['acao'] = ''
    if filtros['demanda_id']:
        where.append('demanda_id = ?')
        params.append(filtros['demanda_id'])
    if filtros['data_inicial']:
        where.append('date(data_hora) >= date(?)')
        params.append(filtros['data_inicial'])
    if filtros['data_final']:
        where.append('date(data_hora) <= date(?)')
        params.append(filtros['data_final'])
    if filtros['q']:
        where.append('(descricao LIKE ? OR detalhes LIKE ?)')
        params.extend((f'%{filtros["q"]}%', f'%{filtros["q"]}%'))
    clause = 'WHERE ' + ' AND '.join(where) if where else ''
    return filtros, clause, params, avisos


@app.route('/auditoria')
def auditoria():
    conn = get_db()
    ensure_schema(conn)
    filtros, clause, params, avisos = filtros_auditoria()
    for aviso in avisos:
        flash(aviso)
    pagina = max(request.args.get('page', 1, type=int), 1)
    total = conn.execute(f'SELECT COUNT(*) FROM logs_auditoria {clause}', params).fetchone()[0]
    total_paginas = max((total + AUDIT_PAGE_SIZE - 1) // AUDIT_PAGE_SIZE, 1)
    pagina = min(pagina, total_paginas)
    logs = conn.execute(
        f'SELECT * FROM logs_auditoria {clause} ORDER BY id DESC LIMIT ? OFFSET ?',
        params + [AUDIT_PAGE_SIZE, (pagina - 1) * AUDIT_PAGE_SIZE]).fetchall()
    usuarios = conn.execute(
        'SELECT DISTINCT usuario FROM logs_auditoria ORDER BY usuario COLLATE NOCASE').fetchall()
    conn.close()
    query_params = {k: v for k, v in request.args.to_dict().items() if k != 'page' and v}
    return render_template('auditoria.html', logs=logs, filtros=filtros, usuarios=usuarios,
                           total=total, pagina_atual=pagina, total_paginas=total_paginas,
                           query_params=query_params)


@app.route('/auditoria/exportar')
def auditoria_exportar():
    conn = get_db()
    ensure_schema(conn)
    filtros, clause, params, _ = filtros_auditoria()
    logs = conn.execute(
        f'SELECT * FROM logs_auditoria {clause} ORDER BY id DESC', params).fetchall()
    registrar_log(conn, 'AUDITORIA_EXPORTADA', 'auditoria', None,
                  f'Exportação CSV da auditoria ({len(logs)} registro(s))',
                  detalhes={k: v for k, v in filtros.items() if v})
    conn.commit()
    conn.close()
    saida = io.StringIO()
    escritor = csv.writer(saida, delimiter=';')
    escritor.writerow(['ID', 'Data/Hora', 'Usuário', 'IP', 'Ação', 'Entidade', 'ID da entidade',
                       'ID da demanda', 'Descrição', 'Detalhes'])
    for log in logs:
        escritor.writerow([log['id'], log['data_hora'], log['usuario'], log['ip'] or '',
                           ACOES_AUDITORIA.get(log['acao'], log['acao']), log['entidade'],
                           log['entidade_id'] or '', log['demanda_id'] or '',
                           log['descricao'], log['detalhes'] or ''])
    nome = f'auditoria_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    # BOM (utf-8-sig) para o Excel abrir os acentos corretamente
    return Response('﻿' + saida.getvalue(), mimetype='text/csv; charset=utf-8',
                    headers={'Content-Disposition': f'attachment; filename={nome}'})


if __name__ == '__main__':
    # Debug do Flask libera execução de código remoto; use apenas localmente.
    app.run(debug=os.environ.get('FLASK_DEBUG', '1') == '1',
            host=os.environ.get('FLASK_HOST', '127.0.0.1'))
